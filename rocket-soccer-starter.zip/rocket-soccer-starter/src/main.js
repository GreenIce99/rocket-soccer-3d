import * as THREE from 'three';
import './style.css';

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x071426);
scene.fog = new THREE.Fog(0x071426, 45, 105);
const camera = new THREE.PerspectiveCamera(65, innerWidth / innerHeight, 0.1, 220);
const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
renderer.setSize(innerWidth, innerHeight);
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.15;
document.body.prepend(renderer.domElement);

scene.add(new THREE.HemisphereLight(0xa8d9ff, 0x182033, 2.0));
const sun = new THREE.DirectionalLight(0xffffff, 3.0);
sun.position.set(-12, 24, 12); sun.castShadow = true;
sun.shadow.mapSize.set(2048, 2048);
sun.shadow.camera.left = -40; sun.shadow.camera.right = 40;
sun.shadow.camera.top = 30; sun.shadow.camera.bottom = -30;
scene.add(sun);

const mat = (color, roughness=0.55, metalness=0.08) => new THREE.MeshStandardMaterial({color, roughness, metalness});
const fieldMatA = mat(0x126c73, 0.88), fieldMatB = mat(0x0e626a, 0.88);
const whiteMat = mat(0xd5f8ff, 0.6), blueMat = mat(0x168dff, 0.35, 0.25);
const orangeMat = mat(0xff792e, 0.35, 0.2), darkMat = mat(0x101a27, 0.45, 0.2);
const glowBlue = new THREE.MeshBasicMaterial({color:0x25baff});
const glowOrange = new THREE.MeshBasicMaterial({color:0xff8b36});

const arena = new THREE.Group(); scene.add(arena);
const fieldW = 32, fieldL = 54, wallH = 2.5;
const floor = new THREE.Mesh(new THREE.PlaneGeometry(fieldW, fieldL), fieldMatA);
floor.rotation.x = -Math.PI/2; floor.receiveShadow = true; floor.position.y = -0.12; arena.add(floor);
for (let i=0;i<9;i++) {
  const stripe = new THREE.Mesh(new THREE.PlaneGeometry(fieldW, fieldL/9), i%2 ? fieldMatA : fieldMatB);
  stripe.rotation.x = -Math.PI/2; stripe.position.set(0,-0.105, -fieldL/2 + (i+.5)*fieldL/9); arena.add(stripe);
}
function box(parent, size, material, pos, cast=true) {
  const m = new THREE.Mesh(new THREE.BoxGeometry(...size), material);
  m.position.set(...pos); m.castShadow=cast; m.receiveShadow=true; parent.add(m); return m;
}
function line(points, material=whiteMat, radius=.055) {
  const curve = new THREE.CatmullRomCurve3(points.map(p=>new THREE.Vector3(...p)));
  const mesh = new THREE.Mesh(new THREE.TubeGeometry(curve, Math.max(8,points.length*4), radius, 6, false), material);
  mesh.position.y=.015; arena.add(mesh); return mesh;
}
line([[-fieldW/2,0,-fieldL/2],[fieldW/2,0,-fieldL/2],[fieldW/2,0,fieldL/2],[-fieldW/2,0,fieldL/2],[-fieldW/2,0,-fieldL/2]], whiteMat);
line([[-fieldW/2,0,0],[fieldW/2,0,0]], whiteMat, .045);
const circlePts = [];
for(let i=0;i<=64;i++){const a=i/64*Math.PI*2;circlePts.push([Math.cos(a)*6,0,Math.sin(a)*6]);}
line(circlePts, whiteMat, .045);
for (const x of [-fieldW/2,fieldW/2]) box(arena,[.5,wallH,fieldL],darkMat,[x,wallH/2,0]);
for (const z of [-fieldL/2,fieldL/2]) {
  const goalW=10, goalH=5;
  box(arena,[fieldW,wallH,.5],darkMat,[0,wallH/2,z]);
  const sign=z<0?-1:1;
  // goal tunnel opening is visual; back wall remains low enough for this starter prototype
  box(arena,[.45,goalH,.45,], sign<0?blueMat:orangeMat,[-goalW/2,goalH/2,z-sign*.15]);
  box(arena,[.45,goalH,.45], sign<0?blueMat:orangeMat,[goalW/2,goalH/2,z-sign*.15]);
  box(arena,[goalW,.45,.45], sign<0?blueMat:orangeMat,[0,goalH,z-sign*.15]);
  box(arena,[goalW,wallH,.5],darkMat,[0,wallH/2,z]);
}
// Remove the central portions of end walls visually by using dark lower side wall blocks.
for (const z of [-fieldL/2,fieldL/2]) {
  box(arena,[(fieldW-10)/2,wallH,.5],darkMat,[-(fieldW+10)/4,wallH/2,z]);
  box(arena,[(fieldW-10)/2,wallH,.5],darkMat,[(fieldW+10)/4,wallH/2,z]);
}
for(let i=0;i<12;i++){
  const z=-fieldL/2+ i*fieldL/11;
  const post=new THREE.Mesh(new THREE.CylinderGeometry(.08,.08,8,8),i%2?glowBlue:glowOrange);
  post.position.set(-fieldW/2-1,4,z); arena.add(post);
  const post2=post.clone();post2.position.x=fieldW/2+1;arena.add(post2);
}

// Car: lightweight arcade physics, oriented toward -Z.
const car = new THREE.Group(); scene.add(car);
const chassis = new THREE.Group(); car.add(chassis);
box(chassis,[2.05,.55,3.15],blueMat,[0,.62,0]);
box(chassis,[1.35,.55,1.35],mat(0x8ee5ff,.25,.35),[0,1.08,-.22]);
box(chassis,[1.2,.38,.75],darkMat,[0,1.1,-.25]);
const wheelGeo = new THREE.CylinderGeometry(.39,.39,.24,16);
const wheels=[];
for(const x of [-1.02,1.02]) for(const z of [-.98,1.02]){
  const w=new THREE.Mesh(wheelGeo,darkMat);w.rotation.z=Math.PI/2;w.position.set(x,.38,z);w.castShadow=true;chassis.add(w);wheels.push(w);
}
const nose = new THREE.Mesh(new THREE.ConeGeometry(.22,.7,8),glowBlue);
nose.rotation.x=-Math.PI/2;nose.position.set(0,.68,-1.78);chassis.add(nose);
const exhaust = new THREE.Mesh(new THREE.ConeGeometry(.28,1.1,12),new THREE.MeshBasicMaterial({color:0x35d9ff,transparent:true,opacity:.7}));
exhaust.rotation.x=Math.PI/2;exhaust.position.set(0,.55,1.9);chassis.add(exhaust);

// Ball
const ballRadius=1.15;
const ball = new THREE.Mesh(new THREE.SphereGeometry(ballRadius,32,24),mat(0xf2f7ff,.25,.2));
ball.castShadow=true;ball.receiveShadow=true;scene.add(ball);
const ballLines=new THREE.Group();ball.add(ballLines);
for(let i=0;i<3;i++){
 const ring=new THREE.Mesh(new THREE.TorusGeometry(ballRadius+.005,.035,6,40),i===0?orangeMat:darkMat);
 ring.rotation.set(i*Math.PI/3, i*Math.PI/4, i*Math.PI/5);ballLines.add(ring);
}
const ballGlow=new THREE.PointLight(0x7bdcff,2,7);ball.add(ballGlow);

// Boost pads
const pads=[];
for(let z=-22;z<=22;z+=11) for(let x of [-12,0,12]){
 const g=new THREE.Group();g.position.set(x,.12,z);
 const base=new THREE.Mesh(new THREE.CylinderGeometry(.75,.75,.12,24),mat(0x0c2435));g.add(base);
 const ring=new THREE.Mesh(new THREE.TorusGeometry(.52,.09,8,24),glowBlue);ring.rotation.x=Math.PI/2;ring.position.y=.12;g.add(ring);
 scene.add(g);pads.push({g,ring,active:true,x,z});
}

const state={started:false, boost:100, scoreBlue:0,scoreOrange:0,time:180, speed:0, yaw:0, vertical:0, vy:0, vx:0, vz:0, ballV:new THREE.Vector3(), cameraMode:0};
const keys={};
addEventListener('keydown',e=>{keys[e.code]=true;if(['Space','ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(e.code))e.preventDefault();
 if(e.code==='KeyR')resetAll(); if(e.code==='KeyC')state.cameraMode=(state.cameraMode+1)%2;
});
addEventListener('keyup',e=>keys[e.code]=false);
const $=id=>document.getElementById(id);
const overlay=$('overlay');
$('playButton').addEventListener('click',()=>{state.scoreBlue=0;state.scoreOrange=0;state.time=180;secondAccumulator=0;$('blueScore').textContent='0';$('orangeScore').textContent='0';$('clock').textContent='3:00';resetAll();state.started=true;overlay.style.display='none';showMessage('KICKOFF!',1000);});
let messageTimer;
function showMessage(msg,ms=1300){$('message').textContent=msg;$('message').style.opacity='1';clearTimeout(messageTimer);messageTimer=setTimeout(()=>$('message').style.opacity='0',ms);}
function resetAll(){car.position.set(0,0,18);state.yaw=0;state.speed=0;state.vx=0;state.vz=0;state.vertical=0;state.vy=0;ball.position.set(0,ballRadius,0);state.ballV.set(0,0,0);state.boost=100;pads.forEach(p=>{p.active=true;p.g.visible=true;});}
function resetKickoff(){car.position.set(0,0,18);state.yaw=0;state.speed=0;state.vx=0;state.vz=0;state.vertical=0;state.vy=0;ball.position.set(0,ballRadius,0);state.ballV.set(0,0,0);}
resetAll();

let last=performance.now(), secondAccumulator=0;
function tick(now){
 requestAnimationFrame(tick);
 const dt=Math.min((now-last)/1000,.035);last=now;
 const t=now*.001;
 pads.forEach(p=>{p.ring.rotation.z=t*1.4;p.g.position.y=.12+Math.sin(t*2+p.x)*.04;});
 if(state.started){
   secondAccumulator+=dt;
   if(secondAccumulator>=1){secondAccumulator-=1;state.time=Math.max(0,state.time-1);const m=Math.floor(state.time/60),s=state.time%60;$('clock').textContent=`${m}:${String(s).padStart(2,'0')}`;if(state.time===0){state.started=false;showMessage(state.scoreBlue===state.scoreOrange?'DRAW!':state.scoreBlue>state.scoreOrange?'BLUE WINS!':'ORANGE WINS!',4000);setTimeout(()=>overlay.style.display='flex',3500);}}
   const forward=(keys.KeyW||keys.ArrowUp?1:0)-(keys.KeyS||keys.ArrowDown?1:0);
   const steer=(keys.KeyA||keys.ArrowLeft?1:0)-(keys.KeyD||keys.ArrowRight?1:0);
   const boosting=(keys.ShiftLeft||keys.ShiftRight)&&state.boost>0;
   const accel=boosting?31:18;
   state.speed+=forward*accel*dt;
   state.speed*=Math.pow(forward===0?.982:.994,dt*60);
   state.speed=THREE.MathUtils.clamp(state.speed,-14,boosting?30:19);
   state.yaw+=steer*dt*(1.65+Math.min(Math.abs(state.speed)*.045,1.1))*(state.speed<-.5?-1:1);
   if(boosting){state.boost=Math.max(0,state.boost-34*dt);exhaust.visible=true;exhaust.scale.setScalar(.7+Math.random()*.6);}else{state.boost=Math.min(100,state.boost+8*dt);exhaust.visible=false;}
   const forwardVec=new THREE.Vector3(-Math.sin(state.yaw),0,-Math.cos(state.yaw));
   state.vx=forwardVec.x*state.speed;state.vz=forwardVec.z*state.speed;
   car.position.x+=state.vx*dt;car.position.z+=state.vz*dt;
   car.position.x=THREE.MathUtils.clamp(car.position.x,-fieldW/2+1.8,fieldW/2-1.8);
   car.position.z=THREE.MathUtils.clamp(car.position.z,-fieldL/2+2,fieldL/2-2);
   if(keys.Space&&state.vertical<.02){state.vy=8.7;state.vertical=.03;}
   state.vy-=22*dt;state.vertical+=state.vy*dt;
   if(state.vertical<0){state.vertical=0;state.vy=0;}
   car.position.y=state.vertical;
   chassis.rotation.y=0;chassis.rotation.z=THREE.MathUtils.clamp(-steer*.08,-.12,.12);
   car.rotation.y=state.yaw;
   wheels.forEach(w=>w.rotation.x+=state.speed*dt*1.8);
   // Car-ball collision and impulse
   const carCenter=new THREE.Vector3(car.position.x,car.position.y+.7,car.position.z);
   const delta=ball.position.clone().sub(carCenter);const dist=delta.length();
   if(dist<ballRadius+1.55){
     if(dist<.001)delta.set(0,0,-1);
     delta.normalize();
     const impulse=Math.max(7,Math.abs(state.speed)*1.15+5)+(boosting?7:0);
     ball.position.addScaledVector(delta,(ballRadius+1.55-dist)+.025);
     state.ballV.addScaledVector(delta,impulse);
     state.ballV.y+=Math.max(0,state.vy)*.45;
   }
   // Ball motion, gravity and damping
   state.ballV.y-=12.5*dt;ball.position.addScaledVector(state.ballV,dt);
   state.ballV.multiplyScalar(Math.pow(.994,dt*60));
   if(ball.position.y<ballRadius){ball.position.y=ballRadius;if(state.ballV.y<0)state.ballV.y*=-.72;state.ballV.x*=.985;state.ballV.z*=.985;}
   if(Math.abs(ball.position.x)>fieldW/2-ballRadius){ball.position.x=Math.sign(ball.position.x)*(fieldW/2-ballRadius);state.ballV.x*=-.78;}
   if(Math.abs(ball.position.z)>fieldL/2-ballRadius){
     const zsign=Math.sign(ball.position.z);
     // Score if ball reaches goal opening; goals are at either end.
     if(Math.abs(ball.position.x)<5 && ball.position.y<5){
       if(zsign<0)state.scoreBlue++;else state.scoreOrange++;
       $('blueScore').textContent=state.scoreBlue;$('orangeScore').textContent=state.scoreOrange;
       showMessage(zsign<0?'BLUE SCORES!':'ORANGE SCORES!',1700);
       resetKickoff();
     } else {ball.position.z=zsign*(fieldL/2-ballRadius);state.ballV.z*=-.8;}
   }
   // Boost pickups
   pads.forEach(p=>{if(!p.active)return;const dx=car.position.x-p.x,dz=car.position.z-p.z;if(dx*dx+dz*dz<2.1*2.1&&Math.abs(car.position.y)<1.2){state.boost=Math.min(100,state.boost+30);p.active=false;p.g.visible=false;}});
   // Follow camera
   const desired=state.cameraMode===0
     ? new THREE.Vector3(car.position.x+Math.sin(state.yaw)*10,car.position.y+6.3,car.position.z+Math.cos(state.yaw)*10)
     : new THREE.Vector3(0,43,0.01);
   camera.position.lerp(desired,1-Math.pow(.001,dt));
   const look=state.cameraMode===0?new THREE.Vector3(car.position.x,car.position.y+1,car.position.z-5):new THREE.Vector3(0,0,0);
   camera.lookAt(look);
 }
 $('boostFill').style.width=`${state.boost}%`;$('boostNumber').textContent=Math.round(state.boost);
 renderer.render(scene,camera);
}
requestAnimationFrame(tick);
addEventListener('resize',()=>{camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight);});
